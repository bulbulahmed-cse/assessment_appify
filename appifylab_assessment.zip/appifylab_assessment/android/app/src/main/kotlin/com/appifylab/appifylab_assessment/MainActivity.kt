package com.appifylab.appifylab_assessment

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
