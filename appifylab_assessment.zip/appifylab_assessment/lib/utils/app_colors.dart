import 'dart:ui';

class AppColor{
  static Color primary = const Color(0xFF115C67);
  static Color secondary = const Color(0xFFE8F54A);
  static Color white = const Color(0xFFFFFFFF);
}