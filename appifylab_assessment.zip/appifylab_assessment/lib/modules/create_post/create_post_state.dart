class CreatePostState {
  CreatePostState init() {
    return CreatePostState();
  }

  CreatePostState clone() {
    return CreatePostState();
  }
}
