abstract class CreatePostEvent {}

class InitEvent extends CreatePostEvent {}
class CreatePost extends CreatePostEvent {}