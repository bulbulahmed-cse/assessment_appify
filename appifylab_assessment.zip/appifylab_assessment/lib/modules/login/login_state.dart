class LoginState {
  LoginState init() {
    return LoginState();
  }

  LoginState clone() {
    return LoginState();
  }
}
