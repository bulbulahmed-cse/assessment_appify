abstract class LoginEvent {}

class InitEvent extends LoginEvent {}
class DoLogin extends LoginEvent {}