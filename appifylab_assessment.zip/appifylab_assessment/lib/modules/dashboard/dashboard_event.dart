abstract class DashboardEvent {}

class InitEvent extends DashboardEvent {}
class Logout extends DashboardEvent {}
class CreatePost extends DashboardEvent {}