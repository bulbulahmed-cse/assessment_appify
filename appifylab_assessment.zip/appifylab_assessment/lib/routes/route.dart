class Routes{
  static String splash = '/';
  static String loginPage = '/login';
  static String dashboard = '/dashboard';
  static String createPost = '/createPost';
}